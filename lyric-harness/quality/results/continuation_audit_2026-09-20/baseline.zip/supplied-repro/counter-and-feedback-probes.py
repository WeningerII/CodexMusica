import os
import json, pathlib, subprocess, sys, copy
from types import SimpleNamespace
ROOT=(pathlib.Path(os.environ['CODEX_MUSICA_REPO'])/'lyric-harness')
OUT=pathlib.Path(os.environ['AUDIT_OUTPUT_DIR'])
sys.path.insert(0,str(ROOT))
from quality.loop import GroupBrief, AnchorSlot
from quality.propose import render_group
from quality.revise import Brief
# Replay the exact same accepted/rejected batch through the native CLI,
# retaining its authenticated machine record to compare with MCP's response.
d=json.loads((OUT/'batch-declarations.json').read_text())
st=json.loads((OUT/'batch-initial-state.json').read_text())
for key in ['connector_declarations','connector_semantic_identity']:
    st.pop(key,None)
answers=json.loads((OUT/'batch-answers.json').read_text())
st['pending']['answer']='\n'.join(f"L{x['line']}: {x['text']}" for x in answers)
state_path=OUT/'batch-native-input-state.json'
state_path.write_text(json.dumps(st))
draft_path=OUT/'batch-native-input.txt';draft_path.write_text('\n'.join(d['draft'])+'\n')
cmd=[sys.executable,str(ROOT/'lyric_harness.py'),'revise',str(draft_path),'--groups='+d['groups'],'--relation='+d['relation'],'--attempts=2','--backtrack=0','--max-rounds=2','--propose=defer:'+str(state_path)]
proc=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,timeout=90)
(OUT/'batch-native-stdout.txt').write_text(proc.stdout)
(OUT/'batch-native-stderr.txt').write_text(proc.stderr)
records=[json.loads(x.split('lyric result: ',1)[1]) for x in proc.stdout.splitlines() if x.startswith('  lyric result: ')]
mcp=json.loads((OUT/'batch-first-accepted-next-rejected.json').read_text())
row={'native_exit':proc.returncode,'native_machine_stale_answers':records[-1]['stale_answers'],'mcp_exit':mcp['exit_code'],'mcp_stale_answers':mcp['stale_answers'],'same_pending_question':json.loads(state_path.read_text())['pending']['record']['line']==mcp['asked']['line']}
(OUT/'counter-comparison.json').write_text(json.dumps(row,indent=2));print(json.dumps(row))
# The normal and atomic group rendering paths share the same prior feedback.
# Exercise the actual record/prior hooks to construct the second-round brief.
import tempfile, contextlib, io
import lyric_harness as LH
with tempfile.TemporaryDirectory() as tmp:
    lines=['My kettle whistles by the stove','My kettle whistles by the stove']
    path=pathlib.Path(tmp)/'state.json'
    with contextlib.redirect_stdout(io.StringIO()):
        _,group,disc=LH._defer_proposer(str(path),lines)
        group.record((1,2),1,lines,False,['nothing was fixed'])
        prior=group.prior((1,2),2)
    brief=Brief(1,lines[0]);brief.round_no=2
    atomic=GroupBrief(1,lines[0],'',(),(),'return',(1,2),brief,tuple(lines),0,prior=prior,whole_repair=True,mandate_description='verbatim return [1,2]')
    ordinary=GroupBrief(1,lines[0],'coat',(),(AnchorSlot(2,lines[1],'boat',(),()),),'A',(1,2),brief,tuple(lines),0,prior=prior)
    normal_text=render_group(ordinary);atomic_text=render_group(atomic)
    row={'prior':prior,'ordinary_displays_reason':'nothing was fixed' in normal_text,'atomic_displays_reason':'nothing was fixed' in atomic_text,'ordinary_displays_round':'ROUND 1' in normal_text,'atomic_displays_round':'ROUND 1' in atomic_text}
    (OUT/'group-prior-comparison.json').write_text(json.dumps(row,indent=2))
    (OUT/'group-prior-ordinary.txt').write_text(normal_text);(OUT/'group-prior-atomic.txt').write_text(atomic_text)
    print(json.dumps(row))

