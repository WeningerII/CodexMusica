import fs from 'node:fs/promises';import{createRequire}from'node:module';
const root=process.env.CODEX_MUSICA_REPO,out=process.env.AUDIT_OUTPUT_DIR;
const require=createRequire(root+'/mcp/package.json');const{Client}=await import(require.resolve('@modelcontextprotocol/sdk/client/index.js'));const{InMemoryTransport}=await import(require.resolve('@modelcontextprotocol/sdk/inMemory.js'));
const{buildServer}=await import(root+'/mcp/tools.js');const{RUNS,_workerInternals}=await import(root+'/mcp/lyric_tools.js');const{decodeState}=await import(root+'/mcp/state_codec.js');
const{withExecutionContext}=await import(root+'/mcp/execution_context.js');
const server=buildServer(),client=new Client({name:'blast-radius-recovery',version:'1'},{capabilities:{}});const[c,s]=InMemoryTransport.createLinkedPair();await Promise.all([client.connect(c),server.connect(s)]);const records=[];
function verdict(r){for(const p of r.content||[])try{const v=JSON.parse(p.text);if(typeof v.exit_code==='number'||v.status==='recovered_artifact')return v;}catch{}return{isError:r.isError,text:(r.content||[]).map(x=>x.text||'').join('\n')};}
async function call(name,args,context){const start=Date.now();const go=()=>client.callTool({name:'lyric_revise',arguments:args},undefined,{timeout:120000});const v=verdict(await(context?withExecutionContext(context,go):go()));await fs.writeFile(out+'/'+name+'.json',JSON.stringify(v,null,2));const st=v.state?decodeState(v.state):null;const row={name,ms:Date.now()-start,isError:v.isError,text:v.text,exit_code:v.exit_code,status:v.status,asked:v.asked,folded:v.folded,final_draft:v.final_draft,accepted_lines:st?.accepted_lines,run_revision:v.run_revision,stop:v.loop_stop_reason,stale_answers:v.stale_answers,answers_on_record:v.answers_on_record,certified:v.certified};records.push(row);console.log(JSON.stringify(row));return v;}
try{
 const prev=JSON.parse(await fs.readFile(out+'/single-correct-target.json','utf8'));
 const poll=await call('pending-repeat-no-answer',{state:prev.state});
 await call('pending-repeat-run-id',{run_id:poll.run_id,run_revision:poll.run_revision});
 await call('pending-recovery-export-control',{state:poll.state,recover_only:true});
 await call('pending-after-no-answer-continue',{run_id:poll.run_id,run_revision:poll.run_revision+1,answer:'The copper kettle cooled beside the door'});
 const initial=JSON.parse(await fs.readFile(out+'/whole-group-initial.json','utf8'));
 await call('whole-group-corrected-valid-control',{state:initial.state,answers:[{line:1,text:'My warm kettle sings by the stove'},{line:2,text:'Your warm kettle steams my coat'}]});
 const b=JSON.parse(await fs.readFile(out+'/batch-initial.json','utf8'));
 const answers=JSON.parse(await fs.readFile(out+'/batch-answers.json','utf8'));
 const ctrl=new AbortController();let accepted=0;
 const interrupted=await call('batch-interrupt-after-accept',{state:b.state,answers},{signal:ctrl.signal,onCheckpoint(r){if(r.status==='accepted'){accepted++;ctrl.abort();}}});
 if(interrupted.state)await call('batch-interruption-resume',{state:interrupted.state});
 const uncertain=await call('uncertified-initial',{draft:['Our kettle whistles by the stove','Your fingers brush my heavy coat'],scheme:'AA',relation:'class:ASSONANCE',writer:'interview',attempts:0,backtrack:0,max_rounds:1});
 if(uncertain.run_id)await call('uncertified-continuation-message',{run_id:uncertain.run_id,run_revision:uncertain.run_revision});
}finally{await fs.writeFile(out+'/recovery-probes-summary.json',JSON.stringify(records,null,2));await Promise.allSettled([client.close(),server.close()]);await _workerInternals.kill();}

