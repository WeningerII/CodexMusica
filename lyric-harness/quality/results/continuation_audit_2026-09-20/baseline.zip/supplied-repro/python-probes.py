import os
import contextlib, io, json, pathlib, sys, tempfile, dataclasses
from types import SimpleNamespace
ROOT=(pathlib.Path(os.environ['CODEX_MUSICA_REPO'])/'lyric-harness')
OUT=pathlib.Path(os.environ['AUDIT_OUTPUT_DIR'])
sys.path.insert(0,str(ROOT))
import lyric_harness as LH
from quality.revise import Reviser, ReviseDeclaration
from quality.loop import revise_loop, _try_tier2
from quality.schemes import mandate
from quality.propose import render_group
from quality.fit import Subdivision
from quality.test_loop import perfect_rhyme_reviser, SILVER_MIND
results=[]
def emit(row):
    results.append(row)
    (OUT/'python-probes-summary.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(row),flush=True)
clean=['My kettle whistles by the stove','Your fingers brush my heavy coat']
good=['My warm kettle sings by the stove','Your warm kettle steams my coat']
bp={'sections':[{'name':'VERSE','bars':2,'start_bar':1,'function':'verse','meter':{'beats':4,'unit':4,'groups':[2,2]}}],
    'lines':[{'text':t,'bar':i+1,'beat':1,'duration':4,'section':'VERSE'} for i,t in enumerate(clean)],
    'hooks':['warm kettle']}
with tempfile.TemporaryDirectory(prefix='lyric-blast-radius-') as tmp:
    bp_path=pathlib.Path(tmp)/'bp.json';bp_path.write_text(json.dumps(bp))
    rv=Reviser(rdecl=ReviseDeclaration(max_rounds=2,attempts_per_line=2,backtrack_width=0))
    m=mandate('AA',n_lines=2,default_relation='class:ASSONANCE')
    seen=[]
    def direct(g):
        seen.append({'attempt':g.attempt,'round':g.brief.round_no,'key':LH._brief_key(g),'feedback':g.reasons,'prompt':render_group(g)})
        return tuple(clean if len(seen)==1 else good)
    result=revise_loop(rv,clean,m,blueprint=str(bp_path),subdivision=Subdivision(2, source='audit declared grid'),propose=lambda *a,**k:None,propose_group=direct)
    emit({'name':'whole-direct-writer-control','calls':len(seen),'attempts':[x['attempt'] for x in seen],'stop':result.stop_reason,'final_draft':result.lines,'accepted':[a.accepted for r in result.rounds for a in r.attempts],'keys_equal':len(seen)>1 and seen[0]['key']==seen[1]['key'],'prompts_differ':len(seen)>1 and seen[0]['prompt']!=seen[1]['prompt']})
    state_path=pathlib.Path(tmp)/'whole-state.json'
    suspensions=[]
    for turn in range(4):
        with contextlib.redirect_stdout(io.StringIO()):
            one,two,disc=LH._defer_proposer(str(state_path),clean)
            try:
                res=revise_loop(rv,clean,m,blueprint=str(bp_path),subdivision=Subdivision(2, source='audit declared grid'),propose=one,propose_group=two)
            except LH._NeedProposal as pending:
                suspensions.append({'kind':pending.kind,'record':pending.record})
                state=disc.state
                answer=clean if len(suspensions)==1 else good
                state['pending']['answer']='\n'.join(f'L{i+1}: {t}' for i,t in enumerate(answer))
                state_path.write_text(json.dumps(state))
                continue
        emit({'name':'whole-deferred-writer','suspensions':len(suspensions),'stop':res.stop_reason,'accepted':[a.accepted for r in res.rounds for a in r.attempts],'tried':[a.tried for r in res.rounds for a in r.attempts],'final_draft':res.lines,'answered_groups':len(disc.state['answered']['propose_group']),'outcomes':disc.state['group_outcomes']})
        break
    # A real ranked group search: two different offers for the same members
    # and round must retain two answers AND their separate verify decisions.
    base=perfect_rhyme_reviser()
    rv2=Reviser(lex=base.lex,decl=base.decl,floor=base.floor,rdecl=ReviseDeclaration(max_rounds=1,attempts_per_line=1,backtrack_width=2))
    m2=mandate([[1,3],[2,3]],n_lines=3,default_relation='RHYME')
    brief=next(x for x in rv2.brief(SILVER_MIND,m2) if x.line_no==3);brief.round_no=1
    path=pathlib.Path(tmp)/'ranked-state.json';asks=[]
    for turn in range(5):
        with contextlib.redirect_stdout(io.StringIO()):
            one,two,disc=LH._defer_proposer(str(path),SILVER_MIND)
            try:
                res,after=_try_tier2(rv2,brief,SILVER_MIND,m2,rv2.rdecl,None,None,None,None,two)
            except LH._NeedProposal as pending:
                asks.append(pending.record)
                st=disc.state
                st['pending']['answer']='\n'.join(f'L{n}: {SILVER_MIND[n-1]}' for n in pending.record['members'])
                path.write_text(json.dumps(st))
                if len(st['answered']['propose_group'])>=2:
                    emit({'name':'ranked-group-outcome-history','pending_questions':len(asks),'answered_records':st['answered']['propose_group'],'outcomes':st['group_outcomes']})
                    break
                continue
        emit({'name':'ranked-group-finished','asks':asks,'answered_records':disc.state['answered']['propose_group'],'outcomes':disc.state['group_outcomes'],'after':after})
        break
