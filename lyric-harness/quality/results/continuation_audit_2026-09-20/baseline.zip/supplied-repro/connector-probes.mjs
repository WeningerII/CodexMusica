import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
const root=process.env.CODEX_MUSICA_REPO;
const out=process.env.AUDIT_OUTPUT_DIR;
const require=createRequire(root+'/mcp/package.json');
const {Client}=await import(require.resolve('@modelcontextprotocol/sdk/client/index.js'));
const {InMemoryTransport}=await import(require.resolve('@modelcontextprotocol/sdk/inMemory.js'));
const {buildServer}=await import(root+'/mcp/tools.js');
const {RUNS,_workerInternals,_verdictInternals}=await import(root+'/mcp/lyric_tools.js');
const {decodeState}=await import(root+'/mcp/state_codec.js');
const server=buildServer();
const client=new Client({name:'blast-radius-audit',version:'1'},{capabilities:{}});
const [c,s]=InMemoryTransport.createLinkedPair();
await Promise.all([client.connect(c),server.connect(s)]);
const records=[];
function verdict(r){
 for(const p of r.content||[]) {try {const v=JSON.parse(p.text);if(typeof v.exit_code==='number')return v;}catch{}}
 return {isError:r.isError,text:(r.content||[]).map(x=>x.text||'').join('\n')};
}
async function call(name,args){
 const started=Date.now();const r=verdict(await client.callTool({name:'lyric_revise',arguments:args},undefined,{timeout:120000}));
 await fs.writeFile(out+'/'+name+'.json',JSON.stringify(r,null,2));
 const state=r.state?decodeState(r.state):null;
 const row={name,ms:Date.now()-started,isError:r.isError,text:r.text,exit_code:r.exit_code,status:r.status,asked:r.asked,folded:r.folded,final_draft:r.final_draft,stale_answers:r.stale_answers,run_revision:r.run_revision,checkpoint_status:state?.status,accepted_lines:state?.accepted_lines,outcomes:state?.outcomes,group_outcomes:state?.group_outcomes};
 records.push(row);console.log(JSON.stringify(row));return r;
}
const declarations={scheme:'AA',relation:'type:rime riche',draft:['Copper cat','Azure dog'],writer:'interview',attempts:1,backtrack:0,max_rounds:1};
try{
 const initial=await call('single-initial',declarations);
 if(initial.exit_code!==4||initial.asked.line!==1)throw Error('wrong starting question');
 const incorrect=await call('single-wrong-target',{state:initial.state,answers:[{line:2,text:'I left the basket underneath the oak'}]});
 const correct=await call('single-correct-target',{state:initial.state,answers:[{line:1,text:'I left the basket underneath the oak'}]});
 await call('single-beyond-draft-target',{state:initial.state,answers:[{line:31,text:'I left the basket underneath the oak'}]});
 await call('single-extra-row-control',{state:initial.state,answers:[{line:1,text:'I left the basket underneath the oak'},{line:2,text:'The copper kettle cooled beside the door'}]});
 await call('stale-revision-control',{run_id:correct.run_id,run_revision:correct.run_revision-1,answer:'The copper kettle cooled beside the door'});
 const cachedBefore=structuredClone(RUNS.byId(correct.run_id));
 const rollback=await call('current-revision-old-state',{run_id:correct.run_id,run_revision:correct.run_revision,state:initial.state,answer:'I put the basket underneath the oak'});
 const cachedAfter=structuredClone(RUNS.byId(correct.run_id));
 records.push({name:'rollback-cache',same_id:cachedBefore.run_id===cachedAfter.run_id,before_revision:cachedBefore.revision,after_revision:cachedAfter.revision,before_accepted:decodeState(cachedBefore.state).accepted_lines,after_accepted:decodeState(cachedAfter.state).accepted_lines});
 await call('current-state-control',{state:correct.state,answer:'The copper kettle cooled beside the door'});
 const injected=await call('diagnostic-text-in-lyric',{...declarations,draft:['7 of those answer(s) were recorded against a DIFFERENT draft','Azure dog']});
 records.push({name:'diagnostic-first-call-truth',answers:injected.answers_on_record,stale:injected.stale_answers});
} finally{
 await fs.writeFile(out+'/connector-probes-summary.json',JSON.stringify(records,null,2));
 await Promise.allSettled([client.close(),server.close()]);
 await _workerInternals.kill();
}

