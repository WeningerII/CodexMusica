import fs from 'node:fs/promises';import{createRequire}from'node:module';
const root=process.env.CODEX_MUSICA_REPO,out=process.env.AUDIT_OUTPUT_DIR;
const require=createRequire(root+'/mcp/package.json');const{InMemoryTransport}=await import(require.resolve('@modelcontextprotocol/sdk/inMemory.js'));
const{buildServer}=await import(root+'/mcp/tools.js');const{connectConnector}=await import(root+'/mcp/client.js');const{_workerInternals}=await import(root+'/mcp/lyric_tools.js');
const server=buildServer({task:{domain:'lyrics'}});const[a,b]=InMemoryTransport.createLinkedPair();await server.connect(a);const client=await connectConnector({task:'lyrics',transport:b});const rows=[];
function verdict(r){for(const p of r.content||[])try{const v=JSON.parse(p.text);if(Number.isInteger(v.exit_code))return v;}catch{}return{isError:r.isError,text:(r.content||[]).map(x=>x.text||'').join('\n')};}
async function call(name,tool,args){try{const v=verdict(await client.call(tool,args));await fs.writeFile(out+'/'+name+'.json',JSON.stringify(v,null,2));const row={name,exit_code:v.exit_code,status:v.status,asked:v.asked,isError:v.isError,text:v.text,run_revision:v.run_revision};rows.push(row);console.log(JSON.stringify(row));return v;}catch(e){const row={name,error:e.message,beforeDispatch:e.beforeDispatch};rows.push(row);console.log(JSON.stringify(row));return row;}}
function answer(asked,draft){if(asked.kind==='propose')return{answer:draft[asked.line-1]};return{answers:(asked.lines||asked.members).map(line=>({line,text:draft[line-1]}))};}
try{
 await call('sdk-sweep','lyric_sweep',{seed_from:31,count:1,lines:12});
 await call('sdk-screen','lyric_screen',{words:['stove','coat'],relation:'class:ASSONANCE'});
 await call('sdk-plan','lyric_plan',{seed:31,lines:12});
 const draft=Array(12).fill('The kettle whistles by the stove');
 await call('sdk-grade','lyric_grade',{seed:31,lines:12,draft});
 const first=await call('sdk-revise-initial','lyric_revise',{seed:31,lines:12,draft,writer:'interview',max_rounds:2,attempts:1,backtrack:0});
 if(first.exit_code!==4)throw Error('initial did not suspend');
 const second=await call('sdk-revise-first-answer','lyric_revise',{run_id:first.run_id,run_revision:first.run_revision,...answer(first.asked,draft)});
 const snapshot=client.snapshot();
 rows.push({name:'sdk-snapshot-after-continuation',returned_revision:second.run_revision,stored_revision:snapshot.continuation?.args?.run_revision,stored_id_matches_returned:snapshot.continuation?.args?.run_id===second.run_id});
 if(second.exit_code===4){
  await call('sdk-revise-current-revision','lyric_revise',{run_id:second.run_id,run_revision:second.run_revision,...answer(second.asked,draft)});
  await call('sdk-revise-omit-revision','lyric_revise',answer(second.asked,draft));
 }
}finally{await fs.writeFile(out+'/sdk-probes-summary.json',JSON.stringify(rows,null,2));await client.close();await server.close();await _workerInternals.kill();}

