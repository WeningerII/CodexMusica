import fs from 'node:fs/promises';
import {createRequire} from 'node:module';
const root=process.env.CODEX_MUSICA_REPO, out=process.env.AUDIT_OUTPUT_DIR;
const require=createRequire(root+'/mcp/package.json');
const {Client}=await import(require.resolve('@modelcontextprotocol/sdk/client/index.js'));
const {InMemoryTransport}=await import(require.resolve('@modelcontextprotocol/sdk/inMemory.js'));
const {buildServer}=await import(root+'/mcp/tools.js');
const {RUNS,_workerInternals}=await import(root+'/mcp/lyric_tools.js');
const {decodeState}=await import(root+'/mcp/state_codec.js');
const server=buildServer(),client=new Client({name:'blast-radius-batches',version:'1'},{capabilities:{}});
const [c,s]=InMemoryTransport.createLinkedPair();await Promise.all([client.connect(c),server.connect(s)]);
const records=[];
function verdict(r){for(const p of r.content||[])try{const v=JSON.parse(p.text);if(typeof v.exit_code==='number')return v;}catch{}return{isError:r.isError,text:(r.content||[]).map(x=>x.text||'').join('\n')};}
async function call(name,args){const start=Date.now();const v=verdict(await client.callTool({name:'lyric_revise',arguments:args},undefined,{timeout:120000}));await fs.writeFile(out+'/'+name+'.json',JSON.stringify(v,null,2));const st=v.state?decodeState(v.state):null;if(st)await fs.writeFile(out+'/'+name+'-state.json',JSON.stringify(st,null,2));const r={name,ms:Date.now()-start,isError:v.isError,text:v.text,exit_code:v.exit_code,status:v.status,asked:v.asked,folded:v.folded,stale_answers:v.stale_answers,final_draft:v.final_draft,loop_stop_reason:v.loop_stop_reason,loop_rounds:v.loop_rounds,answers_on_record:v.answers_on_record,run_revision:v.run_revision,group_outcomes:st?.group_outcomes,outcomes:st?.outcomes};records.push(r);console.log(JSON.stringify(r));return v;}
try{
 const clean=['My kettle whistles by the stove','Your fingers brush my heavy coat'];
 const bp={sections:[{name:'VERSE',bars:2,start_bar:1,function:'verse',meter:{beats:4,unit:4,groups:[2,2]}}],lines:clean.map((text,i)=>({text,bar:i+1,beat:1,duration:4,section:'VERSE'})),hooks:['warm kettle']};
 const init=await call('whole-group-initial',{draft:clean,scheme:'AA',relation:'class:ASSONANCE',blueprint:JSON.stringify(bp),subdivision:2,writer:'interview',attempts:2,backtrack:0,max_rounds:2});
 if(init.exit_code===4){
  const rejected=await call('whole-group-rejected',{run_id:init.run_id,run_revision:init.run_revision,answers:clean.map((text,i)=>({line:i+1,text}))});
  await call('whole-group-valid-control',{state:init.state,answers:[{line:1,text:'My warm kettle sings by the stove'},{line:2,text:'Your warm kettle steams my heavy coat'}]});
 }
 const draft=['we carried every box across the yard','the morning light was thin and cold as tea','she counted out the coins upon the bench','the radio was playing to the moon','a letter came addressed to no one here','the kettle hummed along beside the drum','we left the porch light burning through the night','and nobody remembered where the soap'];
 const decl={draft,groups:'1,2;3,4;5,6;7,8',relation:'class:RHYME',writer:'interview',attempts:2,backtrack:0,max_rounds:2};
 const batch=await call('batch-initial',decl);
 await fs.writeFile(out+'/batch-declarations.json',JSON.stringify(decl,null,2));
 if(batch.exit_code===4&&batch.asked.kind==='propose_batch'){
  const answers=batch.asked.lines.map(line=>({line,text:line===2?'the morning meal had left the toast all charred':draft[line-1]}));
  await fs.writeFile(out+'/batch-answers.json',JSON.stringify(answers,null,2));
  const next=await call('batch-first-accepted-next-rejected',{run_id:batch.run_id,run_revision:batch.run_revision,answers});
  if(next.exit_code===4){
   await call('batch-old-revision-control',{run_id:batch.run_id,run_revision:batch.run_revision,answer:'The same'});
   await call('batch-current-revision-old-state',{run_id:next.run_id,run_revision:next.run_revision,state:batch.state,answers:batch.asked.lines.map(line=>({line,text:draft[line-1]}))});
  }
  const nochange=batch.asked.lines.map(line=>({line,text:draft[line-1]}));
  await call('batch-no-change-control',{state:batch.state,answers:nochange});
  await call('batch-missing-member-control',{state:batch.state,answers:nochange.slice(0,-1)});
  await call('batch-duplicate-member-control',{state:batch.state,answers:[...nochange,nochange[0]]});
  await call('batch-extra-member-control',{state:batch.state,answers:[...nochange,{line:1,text:draft[0]}]});
 }
}finally{await fs.writeFile(out+'/batch-probes-summary.json',JSON.stringify(records,null,2));await Promise.allSettled([client.close(),server.close()]);await _workerInternals.kill();}

