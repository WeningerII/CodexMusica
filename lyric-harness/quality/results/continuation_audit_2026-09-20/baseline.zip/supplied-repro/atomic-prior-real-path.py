import os
import json, pathlib, sys, tempfile, io, contextlib
ROOT=(pathlib.Path(os.environ['CODEX_MUSICA_REPO'])/'lyric-harness')
OUT=pathlib.Path(os.environ['AUDIT_OUTPUT_DIR'])
sys.path.insert(0,str(ROOT))
import lyric_harness as LH
from quality.revise import Reviser, ReviseDeclaration
from quality.loop import _try_tier2
from quality.schemes import mandate
lines=['Copper cat','Copper cat','Azure dog']
m=mandate([[1,3],[1,2]],n_lines=3,returns=[[1,2]],default_relation='class:ASSONANCE')
r=Reviser(rdecl=ReviseDeclaration(max_rounds=2,attempts_per_line=1,backtrack_width=1))
b=next(x for x in r.brief(lines,m) if x.line_no==1)
rows=[]
with tempfile.TemporaryDirectory() as tmp:
 path=pathlib.Path(tmp)/'state.json'
 for turn in range(8):
  with contextlib.redirect_stdout(io.StringIO()):
   one,two,disc=LH._defer_proposer(str(path),lines)
   seen=[]
   def capture(g):
    seen.append(g)
    return two(g)
   capture.record=two.record;capture.prior=two.prior
   try:
    for rn in [1,2]:
     b.round_no=rn
     result,after=_try_tier2(r,b,lines,m,r.rdecl,None,None,None,None,capture)
   except LH._NeedProposal as pending:
    g=seen[-1]
    row={'round':rn,'members':list(g.members),'whole_repair':g.whole_repair,'prior':g.prior,'prompt_contains_prior_reason':bool(g.prior and all(x in pending.prompt for x in g.prior['reasons'])),'prompt_contains_prior_round':'ROUND 1' in pending.prompt}
    rows.append(row)
    (OUT/'atomic-prior-real-path.json').write_text(json.dumps(rows,indent=2))
    (OUT/f'atomic-prior-round{rn}-question{turn}.txt').write_text(pending.prompt)
    st=disc.state
    st['pending']['answer']='\n'.join(f'L{n}: {lines[n-1]}' for n in pending.record['members'])
    path.write_text(json.dumps(st))
    continue
  path.write_text(json.dumps(disc.state))
  break
print(json.dumps(rows,indent=2))
