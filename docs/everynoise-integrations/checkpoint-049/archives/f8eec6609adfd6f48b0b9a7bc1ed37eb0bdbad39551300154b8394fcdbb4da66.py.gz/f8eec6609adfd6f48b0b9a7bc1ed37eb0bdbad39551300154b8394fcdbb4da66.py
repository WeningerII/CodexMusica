from pathlib import Path
import json, hashlib
D=Path(__file__).parent
B=Path('/workspace/CodexMusica-next048/api')
A=Path('/workspace/CodexMusica-next049/api')
Q=Path('/workspace/genre-continuation/research/next049-qualification461/qualification28')
read=lambda p: json.loads(p.read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def musical(c):
    return {k:[{ik:iv for ik,iv in i.items() if ik!='scores'} for i in v] if k=='instruments' else v for k,v in c.items()}
candidate=read(Q/'candidate.json')
assert sha(Q/'candidate.json')=='355fe75cee0396fcaf6b6e701a455ec05f950eb98d9d1988e9668dbae3361047'
old_ids={r['id'] for r in read(B/'traditions/index.json')['items']}
all_ids={r['id'] for r in read(A/'traditions/index.json')['items']}
new_ids={r['id'] for r in candidate['entries']}
assert len(old_ids)==6904 and len(all_ids)==6932 and all_ids==old_ids|new_ids
assert len(new_ids)==28 and not old_ids&new_ids
expected={r['id']:r for r in read(Q/'api-candidate-replays.json')['entries']}
expected.update({r['id']:r['compiled_api'] for r in read(Q/'new-target-runtime.json')['entries']})
errors=[];changed_config=[];changed_recipe=[];hashes={}
for ident in sorted(all_ids):
    p=A/'traditions'/f'{ident}.json';a=read(p)
    b=read(B/'traditions'/p.name) if ident in old_ids else None
    e=expected.get(ident,b)
    assert e is not None
    if musical(a['config'])!=musical(e['config']):errors.append([ident,'config'])
    if a['recipe']!=e['recipe']:errors.append([ident,'recipe'])
    if a['recipe_chars']!=len(a['recipe']) or len(a['recipe'])>1000:errors.append([ident,'length'])
    if b and musical(a['config'])!=musical(b['config']):changed_config.append(ident)
    if b and a['recipe']!=b['recipe']:changed_recipe.append(ident)
    hashes[ident]=sha(p)
old_owners={x['id'] for x in read(B/'instruments/index.json')['items']}
all_owners={x['id'] for x in read(A/'instruments/index.json')['items']}
assert len(old_owners)==1662 and all_owners==old_owners|{'apple_es2_software_synth','flamenco_zapateado_shoes'}
for ident in old_owners:
    if (B/'instruments'/f'{ident}.json').read_bytes()!=(A/'instruments'/f'{ident}.json').read_bytes():errors.append([ident,'old_owner'])
for ident,owner in read(D/'expected-new-owners.json').items():
    assert read(A/'instruments'/f'{ident}.json')==owner
for ident,fields in read(D/'expected-public-source.json').items():
    a=read(A/'traditions'/f'{ident}.json')
    for key,val in fields.items():
        if a.get(key)!=val:errors.append([ident,'source '+key])
assert set(changed_config)|set(changed_recipe)=={'hardstyle','plunderphonics','kapuka_kenyan','musica_jibara','guitarrada_portuguesa'}
report={'status':'PASS' if not errors else 'HOLD','old_payloads':6904,'new_payloads':28,'old_config_changes':len(changed_config),'old_recipe_changes':len(changed_recipe),'changed_old_payloads':5,'intended_scoped_repairs':4,'compatible_scoped_variations':1,'unexpected_differences':len(errors),'old_owners_byte_identical':1662,'new_owners':['apple_es2_software_synth','flamenco_zapateado_shoes'],'candidate_sha256':sha(Q/'candidate.json'),'config_changed_ids':changed_config,'recipe_changed_ids':changed_recipe,'errors':errors,'limits':'Only exact reviewed differences qualified; inherited limitations and three excluded additions remain preserved. Full regression, source-scope and exact-head CI are separate checks.'}
(D/'actual-artifact-review-root.json').write_text(json.dumps(report,indent=2)+'\n')
(D/'actual-artifact-hashes-root.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps(report,indent=2));assert not errors
