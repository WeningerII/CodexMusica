import json,pathlib,hashlib
D=pathlib.Path(__file__).parent;A=pathlib.Path('/workspace/CodexMusica-next051/api');B=pathlib.Path('/workspace/CodexMusica-next050/api');Q=pathlib.Path('/workspace/genre-continuation/research/next051-qualification-root/revised34-six');read=lambda p:json.load(open(p));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def music(c):
 c=json.loads(json.dumps(c))
 for i in c['instruments']:i.pop('scores',None)
 return c
expected={e['id']:e for e in read(Q/'api-candidate-replays.json')['entries']};new=read(Q/'new-target-runtime.json')['entries'];errors=[];changes=[];recipes=[];hashes={};n=0
for p in sorted((B/'traditions').glob('*.json')):
 b=read(p)
 if not isinstance(b,dict) or 'config' not in b:continue
 a=read(A/'traditions'/p.name);e=expected.get(p.stem,b)
 if music(a['config'])!=music(e['config']):errors.append({'id':p.stem,'error':'old_full_config','expected':e['config'],'actual':a['config']})
 if a['recipe']!=e['recipe']:errors.append({'id':p.stem,'error':'old_recipe','expected':e['recipe'],'actual':a['recipe']})
 if music(a['config'])!=music(b['config']):changes.append(p.stem)
 if a['recipe']!=b['recipe']:recipes.append(p.stem)
 assert a['recipe_chars']==len(a['recipe']) and len(a['recipe'])<=1000
 hashes[p.stem]=sha(A/'traditions'/p.name);n+=1
assert n==6971
for r in new:
 a=read(A/'traditions'/(r['id']+'.json'));e=r['compiled_api']
 if music(a['config'])!=music(e['config']):errors.append({'id':r['id'],'error':'new_full_config'})
 if a['recipe']!=e['recipe']:errors.append({'id':r['id'],'error':'new_recipe'})
 assert a['recipe_chars']==len(a['recipe']) and len(a['recipe'])<=1000
 hashes[r['id']]=sha(A/'traditions'/(r['id']+'.json'))
ownererrors=[];owners=0;extensions=read(D/'expected-extended-owners.json')
for p in (B/'instruments').glob('*.json'):
 if p.name=='index.json':continue
 owners+=1
 if p.stem in extensions:
  if read(A/'instruments'/p.name)!=extensions[p.stem]:ownererrors.append(p.stem)
 elif p.read_bytes()!=(A/'instruments'/p.name).read_bytes():ownererrors.append(p.stem)
assert owners==1666
assert read(A/'traditions/index.json')['count']==7005;assert read(A/'instruments/index.json')['count']==1667
for id,owner in read(D/'expected-new-owners.json').items():assert read(A/'instruments'/(id+'.json'))==owner
for id,expected_source in read(D/'expected-public-source.json').items():
 actual=read(A/'traditions'/(id+'.json'))
 for k,v in expected_source.items():
  if actual.get(k)!=v:errors.append({'id':id,'error':'public_source_'+k})
report={'status':'PASS_ALL_OLD_AND_NEW_PAYLOADS' if not errors and not ownererrors else 'HOLD','old_payloads':n,'new_payloads':len(new),'old_config_changed_ids':changes,'old_recipe_changed_ids':recipes,'errors':errors,'old_owners':owners,'unexpected_old_owner_changes':ownererrors,'reviewed_owner_extensions':list(extensions),'new_owners':['dholki_nal'],'expected':'Exact qualified34+6repair298 affected API contexts; all others exact actual050 baseline API. Only derived scores ignored; full recipes exact.','residual_holds':'Inherited musical/model/processing limitations explicitly remain; original34 and earlier projections and all receiver partials/source evidence preserved. No full-profile repair claim.'}
(D/'actual051-audit.json').write_text(json.dumps(report,indent=2)+'\n');(D/'actual051-payload-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='errors'},indent=2));print('errors',len(errors))
