from pathlib import Path
import json, hashlib
D=Path(__file__).parent
B=Path('/workspace/CodexMusica-next050/api')
A=Path('/workspace/CodexMusica-next051/api')
Q=Path('/workspace/genre-continuation/research/next051-qualification-root/revised34-six')
read=lambda p: json.loads(p.read_text())
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def musical(c):
    return {k:[{ik:iv for ik,iv in i.items() if ik!='scores'} for i in v] if k=='instruments' else v for k,v in c.items()}
candidate=read(Q/'candidate.json')
assert sha(Q/'candidate.json')=='ebd9c30b443124b7e8fa1a36d9b974d17c186f85ca0101e3ccddaea303839e1f'
old_ids={r['id'] for r in read(B/'traditions/index.json')['items']}
all_ids={r['id'] for r in read(A/'traditions/index.json')['items']}
new_ids={r['id'] for r in candidate['entries']}
assert len(old_ids)==6971 and len(all_ids)==7005 and all_ids==old_ids|new_ids
assert len(new_ids)==34 and not old_ids&new_ids
expected={r['id']:r for r in read(Q/'api-candidate-replays.json')['entries']}
expected.update({r['id']:r['compiled_api'] for r in read(Q/'new-target-runtime.json')['entries']})
errors=[];changed_config=[];changed_recipe=[];hashes={}
for ident in sorted(all_ids):
    p=A/'traditions'/f'{ident}.json';a=read(p)
    b=read(B/'traditions'/p.name) if ident in old_ids else None
    e=expected.get(ident,b)
    assert e is not None
    if musical(a['config'])!=musical(e['config']):errors.append([ident,'config'])
    if a['recipe']!=e['recipe']:errors.append([ident,'recipe'])
    if a['recipe_chars']!=len(a['recipe']) or len(a['recipe'])>1000:errors.append([ident,'length'])
    if b and musical(a['config'])!=musical(b['config']):changed_config.append(ident)
    if b and a['recipe']!=b['recipe']:changed_recipe.append(ident)
    hashes[ident]=sha(p)
old_owners={x['id'] for x in read(B/'instruments/index.json')['items']}
all_owners={x['id'] for x in read(A/'instruments/index.json')['items']}
assert len(old_owners)==1666 and all_owners==old_owners|{'dholki_nal'}
extensions=read(D/'expected-extended-owners.json')
assert set(extensions)=={'recorded_music_rate_processing','nagara_indian'}
for ident in extensions:
    assert read(A/'instruments'/f'{ident}.json')==extensions[ident]
for ident in old_owners-set(extensions):
    if (B/'instruments'/f'{ident}.json').read_bytes()!=(A/'instruments'/f'{ident}.json').read_bytes():errors.append([ident,'old_owner'])
for ident,owner in read(D/'expected-new-owners.json').items():
    assert read(A/'instruments'/f'{ident}.json')==owner
for ident,fields in read(D/'expected-public-source.json').items():
    a=read(A/'traditions'/f'{ident}.json')
    for key,val in fields.items():
        if a.get(key)!=val:errors.append([ident,'source '+key])
assert set(changed_config)|set(changed_recipe)=={'complextro','dancefloor_dnb','electro_industrial','game_mood','hard_dance','j_core','miami_electro','power_noise','sheffield_bleep_techno','texas_conjunto','zenonesque'}
report={'status':'PASS' if not errors else 'HOLD','old_payloads':6971,'new_payloads':34,'old_config_changes':len(changed_config),'old_recipe_changes':len(changed_recipe),'changed_old_payloads':11,'intended_scoped_repairs':6,'compatible_scoped_variations':5,'unexpected_differences':len(errors),'old_owners_byte_identical':1664,'reviewed_extensions':list(extensions),'new_owners':['dholki_nal'],'candidate_sha256':sha(Q/'candidate.json'),'config_changed_ids':changed_config,'recipe_changed_ids':changed_recipe,'errors':errors,'limits':'Only exact reviewed differences qualified; inherited limitations and original/provisional proposals remain preserved. Full regression, source-scope and exact-head CI are separate checks.'}
(D/'actual-artifact-review-root.json').write_text(json.dumps(report,indent=2)+'\n')
(D/'actual-artifact-hashes-root.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps(report,indent=2));assert not errors
