import collections, hashlib, json, os, pathlib, re, sys, time
sys.path.insert(0, '/work/lyric-harness/quality')
import mutate
OUT = pathlib.Path('/evidence')
original_run = mutate.subprocess.run
results = []
for suite in ['revise', 'loop']:
    rel = f'quality/test_{suite}.py'
    key = mutate.SUITE_SHARDS[rel]
    for mode in ['serial', 'parallel']:
        if mode == 'serial': mutate.SUITE_SHARDS.pop(rel)
        else: mutate.SUITE_SHARDS[rel] = key
        def record(*args, **kwargs):
            child = original_run(*args, **kwargs)
            coordinate = kwargs['env'].get(key, 'all').replace('/', '-')
            prefix = OUT / f'{suite}-{mode}-{coordinate}'
            prefix.with_suffix('.stdout').write_bytes(child.stdout)
            prefix.with_suffix('.stderr').write_bytes(child.stderr)
            return child
        mutate.subprocess.run = record
        env = dict(os.environ, LYRIC_MUTATE_ACTIVE='1')
        env.pop(key, None)
        started = time.monotonic()
        print(f'START {suite} {mode}', flush=True)
        status, tail = mutate.run_complete_suite('/work/lyric-harness', rel, env, mutate.bound_for(rel))
        elapsed = time.monotonic() - started
        logs = list(OUT.glob(f'{suite}-{mode}-*.stdout'))
        text = '\n'.join(p.read_text() for p in logs)
        totals = re.findall(r'TOTAL, this shard \((\d+) of (\d+) sections\)', text)
        checks = collections.Counter(re.findall(r'^\s+PASS\s+(.+)$', text, re.M))
        row = dict(suite=suite,mode=mode,status=status,tail=tail,elapsed_s=elapsed,
                   section_totals=totals,passing_checks=sum(checks.values()),check_labels=dict(checks))
        results.append(row)
        (OUT/'benchmark.json').write_text(json.dumps(results,indent=2)+'\n')
        print(f'END {suite} {mode}: {status}, {elapsed:.3f}s, sections={totals}, checks={sum(checks.values())}', flush=True)
    serial, parallel = results[-2:]
    print(f'{suite} identical assertion census: {serial["check_labels"] == parallel["check_labels"]}',flush=True)
    mutate.SUITE_SHARDS[rel] = key
