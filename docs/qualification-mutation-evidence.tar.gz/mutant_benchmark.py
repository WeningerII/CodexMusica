import hashlib, json, os, pathlib, sys, time
sys.path.insert(0, '/work/lyric-harness/quality')
import mutate
OUT = pathlib.Path('/evidence')
baselines = json.loads((OUT/'benchmark.json').read_text())
assert len(baselines) == 4 and all(r['status']=='PASS' for r in baselines), 'complete green baselines required'
for suite in ['revise','loop']:
    rows = [r for r in baselines if r['suite']==suite]
    assert rows[0]['check_labels'] == rows[1]['check_labels'], 'assertion census changed'
    assert all(sum(int(n) for n, total in r['section_totals']) == int(r['section_totals'][0][1]) for r in rows)
mutation = next(m for m in mutate.MUTATIONS if m.name == 'QR2')
green = list(mutation.subset)
original = pathlib.Path('/work/lyric-harness/quality/revise.py')
before = hashlib.sha256(original.read_bytes()).hexdigest()
schedule = dict(mutate.SUITE_SHARDS)
results=[]
for mode in ['serial','parallel']:
    mutate.SUITE_SHARDS.clear()
    if mode == 'parallel': mutate.SUITE_SHARDS.update(schedule)
    base=f'/tmp/qr2-{mode}'
    os.makedirs(base,exist_ok=True)
    print(f'START QR2 {mode}: both declared suites, previously green in complete baseline',flush=True)
    started=time.monotonic()
    result=mutate.run_mutation(mutation,green,2,'subset',base)
    elapsed=time.monotonic()-started
    after=hashlib.sha256(original.read_bytes()).hexdigest()
    assert after == before, 'source changed'
    results.append(dict(mode=mode,wall_s=elapsed,result=result,source_pristine=after==before))
    (OUT/'mutant-benchmark.json').write_text(json.dumps(results,indent=2)+'\n')
    print(f'END QR2 {mode}: {elapsed:.3f}s; caught={result["caught_by"]}; refused={result["refused_by"]}',flush=True)
